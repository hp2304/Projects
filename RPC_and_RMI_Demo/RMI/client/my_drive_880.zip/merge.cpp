#include <bits/stdc++.h>

using namespace std;

void insertionSort(vector<int> &arr, int n){
	int j, val;
	for(int i=1; i<n; ++i){
		j = i-1;
		val = arr[i];
		while(j>=0){
			if(val < arr[j])
				arr[j+1] = arr[j];
			else
				break;
			--j;
		}
		arr[j+1] = val;
	}
}

int main(int argc, char const *argv[]){
	vector<int> arr{34,342,21,44,22,11,77,2,8,22, 12,3423, 212, 23434, 5775, 23232, 1, 3};
	int n = arr.size();
	// srand(time(0));
	// int pivot_idx = rand()%n;
	// int pivot = arr[pivot_idx];
	// arr[pivot_idx] = arr[n-1];
	// arr[n-1] = pivot;
	insertionSort(arr, n);
	for(int e: arr)
		printf("%d\n", e);
	return 0;
}
